<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    file_put_contents('comments.json', json_encode($data));
    if (json_last_error() === JSON_ERROR_NONE) {
        echo 'success';
    } else {
        echo 'error';
    }
} else {
    echo 'Invalid request method';
}
?>