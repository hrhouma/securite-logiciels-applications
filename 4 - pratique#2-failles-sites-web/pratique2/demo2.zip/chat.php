<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST' && !empty($_POST['message'])) {
    $message = $_POST['message'];
    file_put_contents('chat_log.txt', $message . "\n", FILE_APPEND);
}
?>