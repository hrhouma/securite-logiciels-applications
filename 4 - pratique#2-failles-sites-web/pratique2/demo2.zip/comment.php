<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST' && !empty($_POST['comment'])) {
    $comment = $_POST['comment'];
    $data = json_decode(file_get_contents('comments.json'), true);
    if (json_last_error() === JSON_ERROR_NONE) {
        $data['comments'][] = $comment;
        file_put_contents('comments.json', json_encode($data));
        header('Location: index.html');
    } else {
        error_log('JSON error: ' . json_last_error_msg());
        header('Location: index.html');
    }
} else {
    header('Location: index.html');
}
?>